package com.mooc.house.api.model;

public class AgencyAgent {
  private Integer id;
  private Long    agentId;
  private Integer agencyId;
  
  public Integer getId() {
    return id;
  }
  public void setId(Integer id) {
    this.id = id;
  }
  public Long getAgentId() {
    return agentId;
  }
  public void setAgentId(Long agentId) {
    this.agentId = agentId;
  }
  public Integer getAgencyId() {
    return agencyId;
  }
  public void setAgencyId(Integer agencyId) {
    this.agencyId = agencyId;
  }
  
  

}
